---
license: cc-by-4.0
language:
- en
task_categories:
- visual-question-answering
pretty_name: Perception, Not Reasoning â€” Abstract 2D
size_categories:
- 1K<n<10K
tags:
- theory-of-mind
- visual-reasoning
- synthetic
- neurips-2026
configs:
- config_name: default
  data_files:
  - split: test
    path: images/**
---

# Perception, Not Reasoning â€” Abstract 2D

The original abstract 2D benchmark accompanying **Perception, Not Reasoning, Limits Visual Theory of Mind** (NeurIPS 2026; Oral at the BabyVLM Workshop).

Mohamed Rayan Barhdadi, Syed Talal Wasim, Juergen Gall, Erchin Serpedin, and Hasan Kurban.

This local release contains 1,000 rendered image sequences with questions, deterministic answers, and matched descriptions. All examples are evaluation data. There is no training split. Fifty variants of each of 20 templates cover object tracking (300), goal attribution (200), and false belief (500).

## Load locally

```python
from datasets import load_dataset
data = load_dataset("imagefolder", data_files={"test": "images/**"}, split="test")
print(data[0]["question"], data[0]["answer"])
```

Alternatively read `metadata.csv` with Python's standard `csv` module. `probes.json` preserves the full generator schema, including per-probe seeds and all prompts. Image paths are relative to this directory. `images/metadata.jsonl` provides ImageFolder-compatible annotations. `checksums.json` records file integrity. `croissant.json` describes the local data; public URLs must be supplied before publication.

## Fields

| Field | Meaning |
|---|---|
| file_name / image_path | Rendered PNG, relative to `images/` / dataset root |
| probe_id | Stable template and variant identifier |
| stage | 1: object tracking; 2: goal attribution; 3: false belief |
| template | Scenario family |
| question | Visual-condition question, including answer format |
| answer / answer_kind | Expected answer and grading category |
| panel_count | Number of chronological panels |
| scaffold_percept | Ground-truth perceptual facts |
| scaffold_full | Full ground-truth description |
| text_narration | Matched text-only narrative |

## Construction and provenance

The companion code repository contains `code/abstract/run_experiments.py`, the renderer, template definitions, prompts, and answer grading. Each template has 50 variants indexed 0â€“49. The generator uses `10000 * (template_index + 1) + variant_index` as its per-probe seed; the exact seeds are preserved in `probes.json`. Questions, annotations, and expected answers are produced from the template's underlying scene state. No crowd annotation or human-subject collection is involved. Packaging changes image paths only; it does not alter images or labels.

The original synthetic scenes are not derived from MuMA-ToM or MindPower. Those external benchmarks are not redistributed here. The code release documents how to obtain them from their original sources.

## Intended use and limitations

Use these matched conditions to study visual perception and reasoning bottlenecks under the paper's protocol. The construct is performance on controlled visual false-belief and prerequisite tasks, not a validated measure of human-like social understanding. Clinical assessment, individual diagnosis, demographic comparison, and safety certification are unsupported uses.

The scenes are abstract, synthetic, English-language, and template-based. Repeated layouts and answer conventions can create shortcuts; template variants are not independent new concepts. A model can perform well by exploiting visual or linguistic regularities. Report stage, condition, model panel, parsing failures, and denominators; do not generalize the scores to real-world social competence. The full scaffold intentionally includes information beyond pure perception, so interpret it separately from the perceptual scaffold.

## Personal information and social impact

The released scenes contain fictional geometric characters and locations, not observations of real people. No personal or sensitive participant data were collected. Names and colors are synthetic labels and do not represent demographic samples. English-only templates and simplified social settings limit cultural and population coverage.

The benchmark supports transparent analysis of model limitations. Misuse includes presenting these narrow scores as evidence of human mental-state competence or using them for consequential judgments about people. Publish condition-specific results and the limitations above to reduce this risk.

## License and citation

Original images and annotations are licensed under **Creative Commons Attribution 4.0 International**; see `LICENSE`. Credit the authors and cite `citation.bib`. The companion original code uses MIT. External datasets retain their respective licenses.

## Release status

Prepared locally. No repository, account, or public URL has been selected. See `HOSTING.md` for the remaining NeurIPS hosting steps. Local validation does not establish public accessibility.

Validate file integrity with `python validate_dataset.py`. For Croissant loading, install `requirements-validation.txt`, then run `python validate_dataset.py --croissant`. The unpublished release deliberately omits the recommended publication-date field.
