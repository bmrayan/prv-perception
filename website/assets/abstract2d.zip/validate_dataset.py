"""Validate local checksums, annotation alignment, and optionally Croissant loading."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--croissant', action='store_true', help='Requires mlcroissant')
    args = parser.parse_args()
    checksums = json.loads((ROOT/'checksums.json').read_text(encoding='utf-8'))
    for name, expected in checksums.items():
        path = (ROOT/name).resolve()
        assert path.is_relative_to(ROOT), name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    probes = json.loads((ROOT/'probes.json').read_text(encoding='utf-8'))
    with (ROOT/'metadata.csv').open(encoding='utf-8', newline='') as file:
        rows = list(csv.DictReader(file))
    assert len(probes) == len(rows) == 1000
    assert len({p['id'] for p in probes}) == 1000
    assert Counter(p['stage'] for p in probes) == {1:300, 2:200, 3:500}
    assert set(Counter(p['template'] for p in probes).values()) == {50}
    for probe, row in zip(probes, rows):
        assert probe['id'] == row['probe_id']
        assert probe['expected'] == row['answer']
        assert (ROOT/probe['image_path']).is_file()
    if args.croissant:
        import mlcroissant as mlc
        dataset = mlc.Dataset(ROOT/'croissant.json', mapping={name:ROOT/name for name in ('metadata.csv','probes.json','images.zip')})
        loaded = list(dataset.records(record_set='probes'))
        assert len(loaded) == 1000
        image_count = sum(1 for _ in dataset.records(record_set='images'))
        assert image_count == 1000
        print('Croissant loader read 1,000 annotations and 1,000 images.')
    print(f'Validated 1,000 unique probes, 20 balanced templates, and {len(checksums)} file hashes.')


if __name__ == '__main__':
    main()
