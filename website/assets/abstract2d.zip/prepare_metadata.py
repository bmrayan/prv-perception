"""Build local Croissant metadata, or substitute future public URLs without uploading."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', help='Canonical public dataset URL')
    parser.add_argument('--base-url', help='Direct-download directory URL ending before filenames')
    args = parser.parse_args()
    if bool(args.url) != bool(args.base_url):
        parser.error('Provide both --url and --base-url, or neither for local preparation.')
    archive = ROOT / 'images.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
        for path in sorted((ROOT/'images').glob('*.png')):
            out.write(path, path.relative_to(ROOT).as_posix())
    ctx = {'@language':'en','@vocab':'https://schema.org/','sc':'https://schema.org/',
           'cr':'http://mlcommons.org/croissant/','dct':'http://purl.org/dc/terms/',
           'rai':'http://mlcommons.org/croissant/RAI/','prov':'http://www.w3.org/ns/prov#'}
    for name in ['recordSet','field','dataType','source','fileObject','fileSet','extract','column','fileProperty','includes','containedIn','sha256','citeAs','key','references']:
        ctx[name] = 'cr:'+name
    ctx['conformsTo']='dct:conformsTo'
    ctx['sha256']='sc:sha256'
    ctx['containedIn']='sc:containedIn'
    ctx['dataType']={'@id':'cr:dataType','@type':'@vocab'}
    for name in ['equivalentProperty','repeated','samplingRate','parentField','separator','regex','replace','md5','subField','format','path','isLiveDataset','transform','jsonPath']:
        ctx[name]='cr:'+name
    for name in ['data','examples']:
        ctx[name]={'@id':'cr:'+name,'@type':'@json'}
    distributions=[]
    for name,mime in [('metadata.csv','text/csv'),('probes.json','application/json'),('images.zip','application/zip')]:
        distributions.append({'@type':'cr:FileObject','@id':name,'name':name,
            'contentUrl':args.base_url.rstrip('/')+'/'+name if args.base_url else name,
            'encodingFormat':mime,'sha256':digest(ROOT/name)})
    distributions.append({'@type':'cr:FileSet','@id':'image-files','name':'Rendered sequences',
        'containedIn':{'@id':'images.zip'},'encodingFormat':'image/png','includes':'*.png'})
    with (ROOT/'metadata.csv').open(encoding='utf-8',newline='') as f:
        columns=next(csv.reader(f))
    fields=[{'@type':'cr:Field','@id':'probes/'+name,'name':name,
        'description':name.replace('_',' '),
        'dataType':'sc:Integer' if name in ('stage','panel_count') else 'sc:Text',
        'source':{'fileObject':{'@id':'metadata.csv'},'extract':{'column':name}}} for name in columns]
    metadata={'@context':ctx,'@type':'sc:Dataset','name':'perception-not-reasoning-abstract2d',
        'description':'1,000 synthetic abstract 2D visual-question probes across object tracking, goal attribution, and false belief; 20 templates with 50 variants each.',
        'url':args.url or 'file:./', 'version':'1.0.0',
        'license':'https://creativecommons.org/licenses/by/4.0/',
        'conformsTo':'http://mlcommons.org/croissant/1.0',
        'citeAs':(ROOT/'citation.bib').read_text(encoding='utf-8'),
        'creator':[{'@type':'sc:Person','name':name} for name in ['Mohamed Rayan Barhdadi','Syed Talal Wasim','Juergen Gall','Erchin Serpedin','Hasan Kurban']],
        'distribution':distributions,
        'recordSet':[{'@type':'cr:RecordSet','@id':'probes','name':'probes','description':'One row per evaluation probe. Image paths refer to images.zip.', 'key':{'@id':'probes/probe_id'},'field':fields},
            {'@type':'cr:RecordSet','@id':'images','name':'images','description':'Rendered chronological panel sequences.',
             'field':[{'@type':'cr:Field','@id':'images/image_path','name':'image_path','dataType':'sc:Text',
                       'source':{'fileSet':{'@id':'image-files'},'extract':{'fileProperty':'fullpath'}}},
                      {'@type':'cr:Field','@id':'images/content','name':'content','dataType':'sc:ImageObject',
                       'source':{'fileSet':{'@id':'image-files'},'extract':{'fileProperty':'content'}}}]}],
        'rai:dataLimitations':'Synthetic English templates with repeated layouts and only 20 scenario families. Not validated for real-world social competence, clinical assessment, diagnosis, demographic comparison, or safety certification.',
        'rai:dataBiases':'Template, layout, color, and answer regularities can permit shortcuts. English-only scenarios do not represent demographic or cultural populations; variants share a common construction.',
        'rai:personalSensitiveInformation':'No real-person observations or participant information. Geometric characters and names are fictional synthetic labels; no demographic attributes are sampled.',
        'rai:dataUseCases':'Controlled comparison of image-only, text-only, automatic, perceptual, and full-scaffold conditions. Matched scene states isolate input representation effects within the benchmark; general human-like understanding is not established.',
        'rai:dataSocialImpact':'Supports reproducible diagnosis of model limitations. Risk: overstating social competence or applying scores to consequential judgments about people. Mitigation: report conditions separately, parsing denominators, and template limitations.',
        'rai:hasSyntheticData':True,
        'prov:wasDerivedFrom':{'@id':'probes.json','@type':'prov:Entity','description':'Original synthetic data; per-probe seeds and scene-state metadata are stored here. No external source dataset.'},
        'prov:wasGeneratedBy':{'@type':'prov:Activity','name':'Deterministic scene generation',
            'description':'Companion code/abstract/run_experiments.py renders 20 templates, 50 variants indexed 0–49. Seed = 10000*(template_index+1)+variant_index. Labels and descriptions derive from scene state; no crowd annotation. Release packaging changes image paths only.'}}
    (ROOT/'croissant.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    files=[p for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts and p.name not in ('checksums.json','validation.json')]
    (ROOT/'checksums.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():digest(p) for p in sorted(files)},indent=2)+'\n',encoding='utf-8')
    print('Metadata and checksums prepared locally. Public hosting is still required.' if not args.url else 'Public URLs written locally. No upload performed.')


if __name__ == '__main__':
    main()
