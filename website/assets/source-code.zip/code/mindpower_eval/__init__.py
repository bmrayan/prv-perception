"""MindPower ThreeDWorld evaluation utilities."""

